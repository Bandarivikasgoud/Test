package com.testapp.web;

import com.testapp.model.Student;
import com.testapp.dao.StudentDAO;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/student")
public class StudentServlet extends HttpServlet {
    private StudentDAO studentDAO;

    @Override
    public void init() {
        studentDAO = new StudentDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String idParam = request.getParameter("id");
        String name = request.getParameter("name");
        int age = Integer.parseInt(request.getParameter("age"));
        String email = request.getParameter("email");
        String mobile = request.getParameter("mobile");

        int id = (idParam == null || idParam.isEmpty()) ? 0 : Integer.parseInt(idParam);
        Student student = new Student(id, name, age, email, mobile);

        try {
            studentDAO.saveStudent(student);
            response.sendRedirect("student?action=list");
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ServletException(e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        try {
            if ("edit".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                Student student = studentDAO.getStudentById(id);
              // String name = request.getParameter("name");
              //  int age = Integer.parseInt(request.getParameter("age"));
                //String email = request.getParameter("email");
                //String mobile = request.getParameter("mobile");
              //  @overide student object with setters and getters
                
             //   student.setAge(age);
                
                
                request.setAttribute("student", student);
                RequestDispatcher dispatcher = request.getRequestDispatcher("addStudent.jsp");
                dispatcher.forward(request, response);
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                studentDAO.deleteStudent(id);
                response.sendRedirect("student?action=list");
            } else if ("list".equals(action) || action == null) {
                List<Student> students = studentDAO.getAllStudents();
                request.setAttribute("students", students);
                RequestDispatcher dispatcher = request.getRequestDispatcher("ViewStudents.jsp");
                dispatcher.forward(request, response);
            } else {
                RequestDispatcher dispatcher = request.getRequestDispatcher("addStudent.jsp");
                dispatcher.forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ServletException(e);
        }
    }
}