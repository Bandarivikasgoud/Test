package com.testapp.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.testapp.model.Student;

public class StudentDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/aadhya_test?useSSL=false";
    private String jdbcUsername = "root";
    private String jdbcPassword = "root";

    private static final String INSERT_SQL = "INSERT INTO students (name, age, email, mobile) VALUES (?, ?, ?, ?)";
    private static final String UPDATE_SQL = "UPDATE students SET name=?, age=?, email=?, mobile=? WHERE id=?";
    private static final String SELECT_ALL = "SELECT * FROM students";
    private static final String SELECT_BY_ID = "SELECT * FROM students WHERE id=?";
    private static final String DELETE_SQL = "DELETE FROM students WHERE id=?";

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver"); // For older versions of MySQL Connector/J
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return connection;
    }

    public void saveStudent(Student student) throws SQLException {
        try (Connection conn = getConnection()) {
            if (student.getId() > 0) {
                PreparedStatement stmt = conn.prepareStatement(UPDATE_SQL);
                stmt.setString(1, student.getName());
                stmt.setInt(2, student.getAge());
                stmt.setString(3, student.getEmail());
                stmt.setString(4, student.getMobile());
                stmt.setInt(5, student.getId());
                stmt.executeUpdate();
            } else {
                PreparedStatement stmt = conn.prepareStatement(INSERT_SQL);
                stmt.setString(1, student.getName());
                stmt.setInt(2, student.getAge());
                stmt.setString(3, student.getEmail());
                stmt.setString(4, student.getMobile());
                stmt.executeUpdate();
            }
        }
    }
    //
    
    
    
    
    
    
    
    
    
    
    //

    public List<Student> getAllStudents() throws SQLException {
       List<Student> students = new ArrayList<>();
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(SELECT_ALL);
            ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
               Student student = new Student(
                    rs.getInt("id"),
                   rs.getString("name"),
                    rs.getInt("age"),
                   rs.getString("email"),
                  rs.getString("mobile")
                );
                students.add(student);
            }
       }
        return students;
    }
   
    // THIS ALSO TO GET A EXISTED ID AND GET A STUDENT REQUESTED FOR EDIT AND GET EDITED IN THE DB
    // ✅ Get a single student by ID
    public Student getStudentById(int id) throws SQLException {
        Student student = null;
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(SELECT_BY_ID)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                student = new Student(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getInt("age"),
                    rs.getString("email"),
                    rs.getString("mobile")
                );
            }
        }
        return student;
    }

    // ✅ Delete student by ID
    public void deleteStudent(int id) throws SQLException {
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(DELETE_SQL)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}